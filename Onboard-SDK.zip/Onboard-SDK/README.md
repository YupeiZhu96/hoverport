# ECE 191 - Drone Integration for RF Payload DJI Onboard SDK Application
This is the onboard SDK blah blah

## OSDK Details
This application contains a local copy of DJI Onboard SDK (OSDK) 3.6
